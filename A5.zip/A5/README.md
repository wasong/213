Completed Tasks:
- About Page
- Browsing for Department, Department Courses, Deparment Course Sections
