Note:

If the program loops 'Retrying!' for a while, please restart.
It is set to check max tanks allowed but oddly, there is an infinite loop in creating a tetromino.
