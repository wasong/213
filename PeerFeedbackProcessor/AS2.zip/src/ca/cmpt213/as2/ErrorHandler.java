package ca.cmpt213.as2;

public class ErrorHandler {
    public static void error(String message) {
        System.out.println(message);
        System.exit(-1);
    }
}
